// دالة Vercel خفيفة تشتغل كوسيط بينك وبين Claude API.
// المفتاح السري (ANTHROPIC_API_KEY) يتخزن على Vercel كمتغيّر بيئة —
// ما ينحط أبداً بكود الصفحة، فما يقدر أي زائر يشوفه من "أدوات المطور".
//
// كل صفحة "رحلتك" (index.html) ترسل لهالدالة: model, max_tokens, system, messages
// والدالة تمررها لـ Anthropic بالمفتاح السري وترجع نفس الرد.

module.exports = async (req, res) => {
  // CORS: يسمح لأي صفحة (مثلاً لو استضفت index.html بمكان ثاني عن هالمشروع) تنادي الدالة
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'method_not_allowed' });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    // ما زبطت الإعدادات بعد — رجّع خطأ واضح بدل ما يعلّق الطلب
    res.status(500).json({ error: 'server_not_configured' });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }
  const { model, max_tokens, system, messages } = body || {};

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'invalid_request', message: 'messages is required' });
    return;
  }

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: model || 'claude-sonnet-4-6',
        max_tokens: Math.min(Number(max_tokens) || 1200, 4096),
        system: system || undefined,
        messages
      })
    });

    const data = await upstream.json();
    res.status(upstream.status).json(data);
  } catch (err) {
    res.status(502).json({ error: 'upstream_error', message: String(err && err.message || err) });
  }
};
